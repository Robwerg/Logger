# Example E: This example demonstrates the ability to parse integers and floats from the buffer.

This is based closely on example D, however, every other time it prints out data, it multiplies the data by a factor of 2, just to demonstrate what can be done with floating point data.
