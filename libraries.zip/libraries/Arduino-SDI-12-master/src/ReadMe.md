These are the library source files.
